
class PrimeNumber {
    public:
    int value;
    int get();
    PrimeNumber();
    PrimeNumber(int _value);
    PrimeNumber& operator++();
    PrimeNumber  operator++(int);
    PrimeNumber& operator--();
    PrimeNumber  operator--(int);
};