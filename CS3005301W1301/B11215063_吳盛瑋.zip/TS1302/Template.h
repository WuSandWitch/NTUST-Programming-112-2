#include <cmath>
template<typename T>
auto absoluteValue(T var1, T var2) {
    return abs(var1 - var2);
}
