#include <ctype.h>

#include <iostream>
#include <string>

namespace Authenticate {
void        inputPassword();
std::string getPassword();
}  // namespace Authenticate
