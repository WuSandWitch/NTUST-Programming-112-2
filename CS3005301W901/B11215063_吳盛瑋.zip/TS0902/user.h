#include <iostream>
#include <string>

namespace Authenticate {
void        inputUserName();
std::string getUserName();
}  // namespace Authenticate